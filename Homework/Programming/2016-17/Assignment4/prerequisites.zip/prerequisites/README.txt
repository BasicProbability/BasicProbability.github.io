Prerequisites for Homework 4.

20news-18828: contains the training instances for the NB classifier
dev-set: contains 2000 development files on which accuracy can be checked during development
accuracy_checker.py: script to compare output with dev_key.txt
dev_keys.txt: file containing the true labels for all dev files
Naive_Bayes.py: class implementing the NB classifier. This is what you'll have to work on.
naive_bayes_classifier: allows to run the NB classifier trough the commandline. DO NOT TOUCH!
